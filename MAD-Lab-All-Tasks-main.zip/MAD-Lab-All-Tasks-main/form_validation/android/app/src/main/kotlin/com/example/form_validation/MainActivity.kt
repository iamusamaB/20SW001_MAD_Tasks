package com.example.form_validation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
