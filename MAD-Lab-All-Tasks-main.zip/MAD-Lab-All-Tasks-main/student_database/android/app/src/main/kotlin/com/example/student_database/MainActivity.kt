package com.example.student_database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
