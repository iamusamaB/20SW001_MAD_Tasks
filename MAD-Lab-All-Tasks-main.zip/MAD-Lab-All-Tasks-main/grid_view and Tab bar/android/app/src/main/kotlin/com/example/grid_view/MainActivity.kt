package com.example.grid_view

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
