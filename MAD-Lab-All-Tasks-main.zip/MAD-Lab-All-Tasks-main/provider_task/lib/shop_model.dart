class Model {
  String id, name, price, quantity;
  Model(
      {required this.id,
      required this.name,
      required this.price,
      required this.quantity});
}
