package com.example.provider_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
