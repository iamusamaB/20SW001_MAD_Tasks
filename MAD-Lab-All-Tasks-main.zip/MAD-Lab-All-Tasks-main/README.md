# MAD-Lab-All-Tasks
This repo contains all task of Mobile application development Lab 
